package vo;

public class AlbumVO {
	private int albumNumber;
	
}
