package service;

public class SearchService {

}
